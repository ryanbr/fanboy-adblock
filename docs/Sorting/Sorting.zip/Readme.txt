sortFilters.exe is a command line program that will sort a txt file (adhering to the standard ascii sort order), It also removes any un-needed empty lines.

usage:

sortFilters.exe file.txt

The registry file is for Notepad++ users on a 64bit Windows 7 install. 32bit Windows 7 users should change Program Files (x86) to Program Files in the registry file before using it.

I use Notepad ++ as my default editor for txt file (PSPad seems to do weird things with the context menu am I have not bothered looking to see what's up yet), you will find a sample registry file that will add a "sort filters" context menu for txt files located in the same folder (paths will need to be modifed to suit your needs).

Note:

Does not seem to like XP.

This utility forces a unix/linux style line endings

Utility Author: rickythedragonsteamboat2000